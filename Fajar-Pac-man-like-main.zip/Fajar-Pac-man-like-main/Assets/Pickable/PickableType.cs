public enum PickableType
{
    Coin,
    PowerUp
}